package com.embarkx.firstjobapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstjobappApplicationTests {

	@Test
	void contextLoads() {
	}

}
